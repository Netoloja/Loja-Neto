import { MercadoPagoConfig, Preference } from "@mercadopago/sdk-node";

export default async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", {status:405});
  try {
    const { items } = await req.json();
    if (!Array.isArray(items) || !items.length) {
      return Response.json({error:"Carrinho vazio"}, {status:400});
    }

    // Em produção, o ideal é validar preços/estoque no servidor.
    const client = new MercadoPagoConfig({
      accessToken: process.env.MP_ACCESS_TOKEN
    });
    const preference = new Preference(client);

    const baseUrl = process.env.URL || "https://SEU-SITE.netlify.app";
    const result = await preference.create({
      body: {
        items: items.map(i => ({
          id: String(i.id),
          title: String(i.name),
          quantity: Number(i.qty),
          unit_price: Number(i.price),
          currency_id: "BRL"
        })),
        back_urls: {
          success: `${baseUrl}/?pagamento=sucesso`,
          failure: `${baseUrl}/?pagamento=erro`,
          pending: `${baseUrl}/?pagamento=pendente`
        },
        auto_return: "approved",
        notification_url: `${baseUrl}/.netlify/functions/mercadopago-webhook`
      }
    });

    return Response.json({ init_point: result.init_point });
  } catch (error) {
    console.error(error);
    return Response.json({error:"Não foi possível iniciar o pagamento"}, {status:500});
  }
};