export default async (req) => {
  if (req.method !== "POST") return new Response("OK", {status:200});

  try {
    const event = await req.json();
    console.log("Webhook Mercado Pago:", JSON.stringify(event));

    // PRÓXIMA ETAPA:
    // 1. Validar a assinatura secreta do webhook.
    // 2. Consultar a API do Mercado Pago para confirmar o status.
    // 3. Quando aprovado, gravar o pedido em banco.
    // 4. Disparar e-mail/notificação para o administrador.
    //
    // Nunca considere apenas o retorno do navegador como confirmação de pagamento.

    return Response.json({received:true});
  } catch (error) {
    console.error(error);
    return Response.json({received:false}, {status:400});
  }
};