// Checkout seguro é criado por uma Netlify Function.
let products = [], cart = [];

const money = v => Number(v).toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
const $ = s => document.querySelector(s);

async function loadProducts(){
  try {
    const r = await fetch("./data/products.json");
    products = await r.json();
    renderCategories();
    renderProducts();
  } catch(e) {
    $("#products").innerHTML = "<p>Não foi possível carregar os produtos.</p>";
  }
}
function renderCategories(){
  const cats = [...new Set(products.map(p=>p.category).filter(Boolean))];
  $("#categoryFilter").innerHTML = '<option value="todos">Todas as categorias</option>' +
    cats.map(c=>`<option value="${c}">${c}</option>`).join("");
}
function renderProducts(){
  const cat = $("#categoryFilter").value;
  const list = cat==="todos" ? products : products.filter(p=>p.category===cat);
  $("#products").innerHTML = list.map(p=>`<article class="card">
    <img src="${p.image}" alt="${p.name}">
    <div class="card-body">
      <div class="category">${p.category||""}</div>
      <h3>${p.name}</h3>
      <p class="description">${p.description}</p>
      <div class="price">${money(p.price)}</div>
      <button class="buy" onclick="addToCart('${p.id}')">Adicionar ao carrinho</button>
    </div>
  </article>`).join("");
}
window.addToCart = id => {
  const p = products.find(x=>x.id===id);
  const existing = cart.find(x=>x.id===id);
  existing ? existing.qty++ : cart.push({...p,qty:1});
  renderCart();
};
function renderCart(){
  $("#cartCount").textContent = cart.reduce((s,i)=>s+i.qty,0);
  $("#cartItems").innerHTML = cart.length ? cart.map(i=>`<div class="cart-item">
    <div><strong>${i.name}</strong><br><small>${i.qty} × ${money(i.price)}</small></div>
    <button class="remove" onclick="removeFromCart('${i.id}')">Remover</button>
  </div>`).join("") : "<p>Seu carrinho está vazio.</p>";
  $("#cartTotal").textContent = money(cart.reduce((s,i)=>s+i.price*i.qty,0));
}
window.removeFromCart = id => { cart=cart.filter(i=>i.id!==id); renderCart(); };
$("#categoryFilter").addEventListener("change",renderProducts);
$("#cartButton").onclick=()=>{$("#cart").classList.add("open");$("#overlay").classList.add("show")};
$("#closeCart").onclick=$("#overlay").onclick=()=>{$("#cart").classList.remove("open");$("#overlay").classList.remove("show")};
$("#checkout").onclick=async ()=>{
  if(!cart.length) return alert("Seu carrinho está vazio.");
  const button = $("#checkout");
  button.disabled = true;
  button.textContent = "Abrindo pagamento...";
  try {
    const r = await fetch("/.netlify/functions/create-checkout", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({items:cart})
    });
    const data = await r.json();
    if(!r.ok) throw new Error(data.error || "Erro ao criar pagamento");
    window.location.href = data.init_point;
  } catch(e) {
    alert(e.message);
    button.disabled = false;
    button.textContent = "Pagar com PIX ou cartão";
  }
};
$("#year").textContent=new Date().getFullYear();
loadProducts();