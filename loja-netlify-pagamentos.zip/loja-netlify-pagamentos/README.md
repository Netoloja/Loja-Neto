# Minha Loja com PIX e Cartão — Netlify + Mercado Pago

## O que já está estruturado
- Catálogo de produtos
- Carrinho
- Checkout via Mercado Pago
- PIX e cartão dentro do checkout do Mercado Pago
- Netlify Function para criar o checkout sem expor a chave secreta
- Endpoint de webhook preparado para receber atualizações do pagamento
- Estrutura para painel /admin e edição do catálogo

## IMPORTANTE
A chave `MP_ACCESS_TOKEN` NÃO deve ser colocada no código nem no GitHub.

## Configuração no Netlify
Em Project configuration > Environment variables, crie:
MP_ACCESS_TOKEN = seu Access Token de produção

Depois faça um novo deploy.

## Mercado Pago
1. Crie sua conta de vendedor.
2. Acesse Developers / Suas integrações.
3. Crie uma aplicação.
4. Copie o Access Token correto.
5. Cadastre o webhook:
https://SEU-SITE.netlify.app/.netlify/functions/mercadopago-webhook

## Próxima evolução recomendada
Antes de aceitar vendas reais, implemente:
- validação de assinatura do webhook;
- consulta do status do pagamento na API;
- banco de dados para pedidos;
- notificação por e-mail/WhatsApp;
- validação de preço no servidor para impedir alteração pelo navegador.

Este pacote é a base técnica inicial. Para produção, a confirmação da venda deve ocorrer pelo webhook validado, e não apenas pelo redirecionamento do cliente.
